
#ifndef FEEDMANAGER_H
#define FEEDMANAGER_H
#include "User.h"
#include "Post.h"
#include <vector>
#include <queue>
#include <stack>
#include <map>

class FeedManager {
    map<string, User*> users;
    vector<Post> posts;
    queue<string> notifications;
    stack<string> undoStack;
public:
    void addUser(string name);
    void addFriend(string u1, string u2);
    void createPost(string author, string content);
    void likePost(string user, int postIndex);
    void showFeed(string user);
    void showNotifications(string user);
};
#endif

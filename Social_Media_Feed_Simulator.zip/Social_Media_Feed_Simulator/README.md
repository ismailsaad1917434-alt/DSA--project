
Social Media Feed & Notification Simulator (C++)
-----------------------------------------------
Data Structures Used:
- Queue: Notifications
- Stack: Undo operations
- Linked List (via vector simulation): Feed
- Tree/Graph: Friends network

How to Run:
g++ *.cpp -o app
./app


#include "User.h"
#include "FeedManager.h"
#include <iostream>
using namespace std;

int main() {
    FeedManager feed;
    feed.addUser("Alice");
    feed.addUser("Bob");

    feed.addFriend("Alice", "Bob");

    feed.createPost("Alice", "Hello World!");
    feed.likePost("Bob", 0);

    feed.showFeed("Bob");
    feed.showNotifications("Alice");

    return 0;
}

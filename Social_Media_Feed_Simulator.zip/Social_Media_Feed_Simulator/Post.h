
#ifndef POST_H
#define POST_H
#include <string>
using namespace std;

struct Post {
    string author;
    string content;
    int likes;
};
#endif

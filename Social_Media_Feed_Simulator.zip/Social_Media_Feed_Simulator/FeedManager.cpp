
#include "FeedManager.h"
#include <iostream>
using namespace std;

void FeedManager::addUser(string name) {
    users[name] = new User(name);
}

void FeedManager::addFriend(string u1, string u2) {
    users[u1]->friends.push_back(u2);
    users[u2]->friends.push_back(u1);
}

void FeedManager::createPost(string author, string content) {
    posts.push_back({author, content, 0});
}

void FeedManager::likePost(string user, int postIndex) {
    posts[postIndex].likes++;
    notifications.push(user + " liked your post");
    undoStack.push("like");
}

void FeedManager::showFeed(string user) {
    cout << "Feed for " << user << endl;
    for (auto &p : posts) {
        cout << p.author << ": " << p.content << " [Likes: " << p.likes << "]" << endl;
    }
}

void FeedManager::showNotifications(string user) {
    cout << "Notifications for " << user << endl;
    while (!notifications.empty()) {
        cout << notifications.front() << endl;
        notifications.pop();
    }
}

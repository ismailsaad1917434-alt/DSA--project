
#include "User.h"
User::User(string n) { name = n; }


#ifndef USER_H
#define USER_H
#include <string>
#include <vector>
using namespace std;

class User {
public:
    string name;
    vector<string> friends;
    User(string n);
};
#endif
